//EXERCICIO 1
function calcular(){
    let n1 = document.getElementById("N1").value
    let n2 = document.getElementById("N2").value

    let r = (n1 - n2)
    alert(r)
}
//EXERCICIO 2
function resultado(){
    let nn1 = document.getElementById("n1").value
    let nn2 = document.getElementById("n2").value
    let nn3 = document.getElementById("n3").value

    let RR = (nn1 * nn2 * nn3)
    alert(RR)
}
//EXERCICIO 3 
function calc(){
    let nnn1 = document.getElementById("1").value
    let nnn2 = document.getElementById("2").value

    let RRR = (nnn1 / nnn2)
    alert(RRR)
}
//EXERCICIO 4
function media(){
    let nota1 = document.getElementById("nota1").value
    let nota2 = document.getElementById("nota2").value

    let media = (nota1 * 2 + nota2 * 3)/2
    alert(media)
}
//EXERCICIO 5
function preconovo(){
    let preco = document.getElementById("preco").value

    let preconovo = preco - (10/100*preco)
    alert(preconovo)
}
//EXERCICIO 6
function salario(){
    let salario = Number(document.getElementById("salario").value)
    let vendas = Number(document.getElementById("vendas").value)
    let comissão = 4/100*vendas
    let salariofinal = salario + comissão

    alert(salariofinal)
}
//EXERCICIO 7
function peso(){
    let peso = Number(document.getElementById("peso").value)

    let peso15 = peso + 15/100*peso
    let peso20 = peso - (20/100*peso)
    alert("se engordar " + peso15 + ", se emagrecer " + peso20)
}
//EXERCICIO 8
function gramas(){
    let pesokilos = Number(document.getElementById("pesokilos").value)

    let pesogramas = pesokilos * 1000
    
    alert(pesogramas + 'g')
}
//EXERCICIO 9
function trapezio(){
    let Bmaior = Number(document.getElementById("BMaior").value)
    let Bmenor = Number(document.getElementById("BMenor").value)
    let Altura = Number(document.getElementById("Altura").value)

    let Area = ((Bmaior + Bmenor) * Altura) / 2

    alert(Area)
}
//EXERCICIO 10
function areaquadrado(){
    let Lado = Number(document.getElementById("ladoquadrado").value)

    let areaquadrado = Lado * Lado
    alert("a área do quadrado é " + areaquadrado)
}